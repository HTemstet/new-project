import { Component, OnInit} from '@angular/core';
import { Router, RouterModule, ROUTES } from '@angular/router';
import { AreaService } from 'src/app/Services/area.service';
import { GlobalService } from 'src/app/Services/global.service';
import { ValidationService } from 'src/app/Services/validation.service';
import { PeopleAreaService } from 'src/app/Services/people-area.service';
import { RequestService } from 'src/app/Services/request.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  aboutArea=false;
  AreaCode=0;
  AreaSearch=null;

  constructor(private GlobalServ:GlobalService, private AreaServ:AreaService,
    private PeopleAreaServ:PeopleAreaService,private ValidationServ:ValidationService, 
    private RequestServ:RequestService,private myrouter:Router) { }
    ngOnInit() {
    // RouterModule.forRoot(ROUTES,{ useHash: true })
    this.AreaServ.getAreas();
    this.dispalyAreaselect()
  }   
  // לבדוק אם צריך ואיפה את המשתנה OccuredArea
gotoHomeAll(){
  this.PeopleAreaServ.getAllads().subscribe(
    data=>
    {
      this.PeopleAreaServ.Allads=data;
      this.PeopleAreaServ.adses=data;
      this.AreaServ.aboutArea='';
      this.myrouter.navigateByUrl('/enter', {skipLocationChange: true}).then(()=>
      this.myrouter.navigate(["ads"]));
    },     
    error=>console.log(error.message),
    ()=>console.log('finished')
  );
}
enter()
{
  this.GlobalServ.display = true;
  this.ValidationServ.sendingTempPass=false;
  this.myrouter.navigateByUrl('ads', {skipLocationChange: true}).then(()=>
  this.myrouter.navigate(["/enter"])); 
}
newUser()
{
  this.ValidationServ.knownPeople=false;
  this.myrouter.navigateByUrl('ads', {skipLocationChange: true}).then(()=>
  this.myrouter.navigate(["/validation"]));  
}
aboutEmployer()
{
  this.RequestServ.Request.Employee=false;
  this.myrouter.navigateByUrl('ads', {skipLocationChange: true}).then(()=>
  this.myrouter.navigate(["/aboutemployer"]));  
}
dispalyAreaselect()
{
  this.RequestServ.Request.Employee=true;
  this.myrouter.navigateByUrl('ads', {skipLocationChange: true}).then(()=>
  this.myrouter.navigate(["/freeorbyrareaserach"]));  
}

}
