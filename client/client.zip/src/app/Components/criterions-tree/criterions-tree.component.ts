import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef} from '@angular/core';
import { CriterionsofAreas } from 'src/app/Classes/CriterionsofAreas';
import { TypesEnum, RequestService } from 'src/app/Services/request.service';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { Options } from 'ng5-slider';
import {NgModel, FormGroup } from '@angular/forms';

declare const google:any;
@Component({
  selector: 'app-criterions-tree',
  templateUrl: './criterions-tree.component.html',
  styleUrls: ['./criterions-tree.component.css']
})
export class CriterionsTreeComponent implements OnInit{
  constructor(public RequestServ:RequestService){}
  @ViewChild("mode",{static:false}) mode:ElementRef;
  // @ViewChild('CriterionsForm',{static:false}) myform;
   //validationslist=[];
  ngOnInit() {
    //יתכן וחלק מהולידציות מיותרות
    //אין בזה בכלל שימוש בינתיים
    // this.validationslist.push(['apply',''])
    // this.validationslist.push(['bind',''])
    // this.validationslist.push(['call',''])
    // this.validationslist.push(['compose',''])
    // this.validationslist.push(['composeAsync',''])
    // this.validationslist.push(['email','הי, האימייל אינו תקין'])
    // this.validationslist.push(['max','המספר גבוה מידי!'])
    // this.validationslist.push(['maxLength',''])
    // this.validationslist.push(['min','המספר נמוך מידי!'])
    // this.validationslist.push(['minLength',''])  
    // this.validationslist.push(['nullValidator',''])
    // this.validationslist.push(['pattern','התוכן איתו תואם את התבנית הרצויה'])
    // this.validationslist.push(['required','הי, שכחת להכניס ערך!'])
  } 
 @Input()list=new Array<CriterionsofAreas>();
 @Input()parentForm:FormGroup
 @Output() Criterion:EventEmitter<any>=new EventEmitter<any>();
 @Output() invalid:EventEmitter<any>=new EventEmitter<any>();
 @Output() valid:EventEmitter<any>=new EventEmitter<any>();
 @ViewChild("crit1",{static:false}) crit1:NgModel;
 @ViewChild("crit2",{static:false}) crit2:NgModel;
 @ViewChild("crit3",{static:false}) crit3:NgModel;
 @ViewChild("crit4",{static:false}) crit4:NgModel;
 @ViewChild("crit5",{static:false}) crit5:NgModel;
 @Input() ShowLevel=false;
//  לאקורדיון החדש
 @Input() FirstCriterion=true;
//  
 EnumTypes=TypesEnum;
 CriterionCode=0;
 CriterionShow=0;
 value: number = 100;
 DisplayDirections=false;
 TreePartOfAList=new Array<CriterionsofAreas>();
 changeI=false;
 Leveloptions: Options = {  //רמת עדיפות
  floor: 0,
  ceil: 10,
};
//invalid_message="";
InputValidations(i:CriterionsofAreas,ele)
{
  let v;
// JSON.stringify({name:'6',f:0})// ממיר אוביקט ג'ייסון למחרוזת - לא שימושי לנו כרגע
if(i.FeildValidation!=null&&i.FeildValidation!='')
{
  //את השורה הבאה לא צריך - היא רק לצורך בדיקה
  //i.FeildValidation='{"minLength":"4","maxLength":"8","required":"required","max":"8"}';
try{
    JSON.parse(i.FeildValidation,(key, value) => 
    {
    if(key!='')
    try{ele.srcElement.setAttribute(key,value);}
    catch{console.log('not fitting validation attribute');}
    });
  }
  catch{
      console.log(i.Name+' FeildValidation is not a json object');
    }
   if(i.FeildValidation.indexOf('multiple')>-1)
      i.multipleselect=true;
   else
      i.multipleselect=false;
}
 //המרת מחרוזת לאיבר ג'ייסון
}
ShowValidationMessage(ele,i:CriterionsofAreas)
{
  debugger;
//  if(this.crit1.errors!=null)
//    this.invalid_message=JSON.stringify(this.crit1.errors); 
  i.invalid_message=ele.srcElement.validationMessage;
  if(ele.srcElement.validationMessage!="")
    this.invalid.emit(i)
  else
    this.valid.emit(i)
}
requiredtag(i:CriterionsofAreas)
{
 if(i.required)
 {
   if(i.FeildValidation.indexOf('required')>-1)
    return '**'
   else 
    return '*'
 }
 return '';
}
formatLabel(value: number) {
  if (value >= 1000) {
    return Math.round(value / 1000);
  }
  return value;
}
DisplayChildren(El:CriterionsofAreas)
{
  this.changeI=true;
  if(El.CriterionsofAreasTree.length>0)
  {
    if(this.CriterionShow==El.CriterionofAreaCode)
    {
      this.CriterionShow=0;
      El.PartOfAListTree=new Array<CriterionsofAreas>()
      El.RegularTree=new Array<CriterionsofAreas>()
    }
    else
    {
    El.PartOfAListTree=new Array<CriterionsofAreas>();
    El.RegularTree=new Array<CriterionsofAreas>();
    this.CriterionShow=El.CriterionofAreaCode;
    console.log('CriterionShow: ',this.CriterionShow);
     El.CriterionsofAreasTree.forEach(x=>
        {
        if (x.TypeEnum==this.EnumTypes.PartOfaList)
        {
          El.PartOfAListTree.push(x);
        } 
        else
        {
          El.RegularTree.push(x);
        }})
    }
    this.CriterionCode=El.CriterionofAreaCode;
  }
}
GetList(i:CriterionsofAreas):Array<CriterionsofAreas>
{
  let x:CriterionsofAreas=null;
  if(i.PartOfAListTree!=undefined&&i.PartOfAListTree!=null)
       x= i.PartOfAListTree.find(x=>x.CriterionofAreaCode==i.ValueofCriterion);
  if(x!=null&&x!=undefined) 
     return x.CriterionsofAreasTree;
  }
CalculateDistanceByWalkDrive(){
  this.directionsService.route(this.request, function(response, status) {
     if ( status == google.maps.DirectionsStatus.OK ) {
       console.log("Walking Distance",response.routes[0].legs[0].duration.text); //מחזיר מרחק הליכה בדקות לדוג' 37 דקות
       console.log("km Distance",response.routes[0].legs[0].distance.text); //מחזיר מרחק בקילומטר
      this.drivingDistance=response.routes[0].legs[0].duration.text;
     }
     else {
       // oops, there's no route between these two locations
       // every time this happens, a kitten dies
       // so please, ensure your address is formatted properly
     }
   })
 }
handleAddressChange(address:Address){
  console.log(address.name)
  // this.PeopleServ.surf.Name=address.name;
}
directionsService=new google.maps.DirectionsService();
request = {
origin      :'Givat Shaul, ירושלים, ישראל' , // a city, full address, landmark etc'Melbourne VIC',
destination : 'Har Nof, ירושלים, ישראל',//Sydney NSW
travelMode  : google.maps.DirectionsTravelMode.WALKING//שיטת חישוב:הליכה/נסיעה
}; 
func()
{
console.log(this.mode.nativeElement.value)
this.request.travelMode=  google.maps.DirectionsTravelMode[this.mode.nativeElement.value]
 this.CalculateDistanceByWalkDrive();
}
ShowDirections()
    {
      this.DisplayDirections=!this.DisplayDirections
    }
}
