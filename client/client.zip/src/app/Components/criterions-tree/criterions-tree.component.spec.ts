import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CriterionsTreeComponent } from './criterions-tree.component';

describe('CriterionsTreeComponent', () => {
  let component: CriterionsTreeComponent;
  let fixture: ComponentFixture<CriterionsTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CriterionsTreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CriterionsTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
