import { Component, OnInit } from '@angular/core';
import { PeopleService } from 'src/app/Services/people.service';
import { GlobalService } from 'src/app/Services/global.service';
import { MessageService } from 'primeng/api';
import { ValidationService } from 'src/app/Services/validation.service';

@Component({
  selector: 'app-personal-details',
  templateUrl: './personal-details.component.html',
  styleUrls: ['./personal-details.component.css']
})
export class PersonalDetailsComponent implements OnInit {
  constructor(private GlobalServ:GlobalService,private PeopleServ:PeopleService,
    private ValidationServ:ValidationService,
    private messageService: MessageService) { }
    ShowValidation=false;
  ngOnInit() {
  }
  OkFunc()
  {
    this.PeopleServ.updatepeople().subscribe(
      data=>alert('השינויים נשמרו'),
      error=>console.log(console.log(error.message)),
     ()=>console.log('finished')
 );
  }
  ShowPeopleValidation()
{
this.ValidationServ.GetPeopleValidation(this.PeopleServ.surf.Code);
this.ShowValidation=true;
}
ClosePeopleValidation()
{
this.ShowValidation=false;
}
SaveValidations()
{
  this.ValidationServ.SavePeopleValidation().subscribe(
    data=>console.log('success'),
    error=>console.log(error.message),
    ()=>console.log('finished')
    );
}
}