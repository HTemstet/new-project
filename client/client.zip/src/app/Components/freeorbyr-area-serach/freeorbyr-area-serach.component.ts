  import { Component, OnInit } from '@angular/core';
  import { SimpleObject } from 'src/app/Classes/SimpleObject';
  import { AreaService } from 'src/app/Services/area.service';
  import { GlobalService } from 'src/app/Services/global.service';
  import { Router } from '@angular/router';
  import { PeopleAreaService } from 'src/app/Services/people-area.service';
import { MessageService } from 'primeng/api';
  
  @Component({
    selector: 'app-freeorbyr-area-serach',
    templateUrl: './freeorbyr-area-serach.component.html',
    styleUrls: ['./freeorbyr-area-serach.component.css']
  })
  export class FreeorbyrAreaSerachComponent implements OnInit {
  
    constructor(private GlobalServ:GlobalService,
      private PeopleAreaServ:PeopleAreaService,
      private AreaServ:AreaService,
      private messageService: MessageService,
      private myrouter:Router) { }
  
    ngOnInit() {
      this.AreaServ.showAreas=false;
      this.AreaServ.AreaSearch=false;
      this.GlobalServ.showTitle=false;
    }
    aboutArea=false;
    AreaCode=0;
    SearchType(val:boolean)
    {
      this.AreaServ.showAreas=val;
      this.AreaServ.AreaSearch=val;
    }
    ShowAboutArea(Code:SimpleObject)
  {
    this.AreaCode=Code.Code;
   this.aboutArea=true;
   this.AreaServ.aboutArea=this.AreaServ.Allareas.find(x=>x.Code==Code.Code).AboutArea;
  }
  ChooseArea()
  {
    if(this.AreaCode==0)
      //this.AreaServ.Area=1;
        this.messageService.add({severity:'error',summary:'אופס', detail:'רגע רגע, שכחת לבחור תחום'});
    else  
    {
    this.AreaServ.Area=this.AreaCode;
    this.aboutArea=false;
    this.GlobalServ.OccuredArea=true;
    this.myrouter.navigateByUrl('/enter', {skipLocationChange: true}).then(()=>
    this.myrouter.navigate(["request"]));
    this.AreaServ.FullArea=this.AreaServ.Allareas.find(x=>x.Code==this.AreaServ.Area);
    }
  }
}
