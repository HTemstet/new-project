import { Component, OnInit, HostListener } from '@angular/core';
import { PeopleAreaService } from 'src/app/Services/people-area.service';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { AreaService } from 'src/app/Services/area.service';
@Component({
  selector: 'app-ads',
  templateUrl: './ads.component.html',
  styleUrls: ['./ads.component.css']
})
export class AdsComponent implements OnInit {
  images: any[];
  load=false;
  constructor(private PeopleAreaServ:PeopleAreaService,private AreaServ:AreaService) { }
  ngOnInit() {
    console.log('kkkj');
     this.images = [];
     for(let i=0;i<this.PeopleAreaServ.adses.length;i++)
     this.images.push({source:this.PeopleAreaServ.PictureNative+this.PeopleAreaServ.adses[i], alt:'Description for Image 1', title:'Title 1'});
     for(let i=0;i<this.PeopleAreaServ.adses.length;i++)
     this.images.push({source:this.PeopleAreaServ.PictureNative+this.PeopleAreaServ.adses[i], alt:'Description for Image 1', title:'Title 1'});
     for(let i=0;i<this.PeopleAreaServ.adses.length;i++)
     this.images.push({source:this.PeopleAreaServ.PictureNative+this.PeopleAreaServ.adses[i], alt:'Description for Image 1', title:'Title 1'});    
    }
    d(event)
    {
     console.log( event.image); 
    }
    appload()
    { this.load=true;}
    closeload()
    { this.load=false;}
    //
    employee=true;
change()
{
  if(this.employee==false)
  {
    document.querySelector("p").style.color="rgb(245, 20, 12)";
    document.querySelector("h4").style.color="rgb(245, 20, 12)";
    document.querySelector("h1").style.color="#34495e";
    document.querySelector("i").style.color="#34495e";  
  }
  }
}
