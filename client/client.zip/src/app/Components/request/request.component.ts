import { Component, OnInit,ViewEncapsulation, ViewChildren, QueryList, ViewChild} from '@angular/core';
import { CriterionsofAreas } from 'src/app/Classes/CriterionsofAreas';
import { RequestService, TypesEnum } from 'src/app/Services/request.service';
import { AreaService } from 'src/app/Services/area.service';
import { PeopleService } from 'src/app/Services/people.service';
import { PeopleAreaService } from 'src/app/Services/people-area.service';
import { SimpleObject } from 'src/app/Classes/SimpleObject';
import { GlobalService } from 'src/app/Services/global.service';
import {MenuItem, MessageService} from 'primeng/api';
import { Router } from '@angular/router';
import { ValidationService } from 'src/app/Services/validation.service';
import { NgForm } from '@angular/forms';
import { debug } from 'util';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
// import * as $ from "jquery";
export class TodoItemNode {
  children: TodoItemNode[];
  item: string;
}
const s = this;
@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class RequestComponent implements OnInit {          
  constructor(private GlobalServ:GlobalService,
    private AreaServ:AreaService,
    private PeopleServ:PeopleService,
    private PeopleAreaServ:PeopleAreaService,
    private RequestServ:RequestService,
    private ValidationServ:ValidationService,
    private messageService:MessageService,
    private myrouter:Router) {
  }
  CriterionsofAreaListSmall=new Array<CriterionsofAreas>();
  showprophilbutton=false;
  showspecificpeopleprophil=false;
  ValueofListCode=0;
  DisplayLivingPlace=false;
  DisplayWorkingPlace=false;
  DisplayLearningPlaces=false;
  DisplayExperiencese=false;
  DisplayFavoritePeople=false;
  DisplayTimes=false;
  value: number = 100;
  items: MenuItem[];
  TypeofNewCriterion=0;
  ShowTypes=true;
  activeIndex=0;
  EnumTypes=TypesEnum;
  TitlesList:Array<SimpleObject>;
  SendingJobOffers=false;
  modelV=false;
  rightChoice=1;
  Title=new SimpleObject();
  FormValidations=new Array<CriterionsofAreas>(); 
  @ViewChild("CriterionsForm",{static:false}) CriterionsForm:NgForm;
  ngOnInit() 
  {
  // setTimeout(() => {
  // this.FormFunc();
  // this.PaymentFunc();
  // }, 0);
  this.getTitles();
  this.ChooseEmployeeFunc();
  } 
  ChooseEmployeeFunc()
    {
      this.RequestServ.getAllCriterionsByArea().subscribe(
        data=>{
         console.log('ChooseEmployeeFunc',data);
         this.RequestServ.Request.CriterionsofRequests=data.CriterionsofAreaList;
         this.TypesFunc();
         console.log('criterions', this.RequestServ.Request.CriterionsofRequests[0])
         this.RequestServ.FavoritePeople=data.FavoritePeopleList;
         this.ChooseTitle(this.TitlesList[0]);
        },
        error=>console.log(error.message),
        ()=>console.log('finished')
      );
    }
  getTitles()
  {
    this.RequestServ.getTitles().subscribe(
      data=>{
        this.TitlesList=data;
        this.items = [];
        for(let i=0;i<this.TitlesList.length;i++)
        {
          this.items.push(
            {label: this.TitlesList[i].Name,
          command: (event: any) => {
            this.activeIndex = this.TitlesList[i].Code-1;
            this.ChooseTitle(this.TitlesList[i])
        }}  ); }
        this.items.push({label: '+'
         ,
         command: (event: any) => {
        }})
      },
      error=>console.log(error.message),
      ()=>console.log('finished')
    );
  }
  saveRequiredValidations(CriterionsList:Array<CriterionsofAreas>,PartOfaList=false)
  {
    for(let i=0;i<CriterionsList.length;i++)
    {
      //את השורה הבאה לא צריך - היא רק לצורך בדיקה
      //CriterionsList[i].FeildValidation= '{"minLength":"4","maxLength":"8","required":"required","max":"8"}';
      if(CriterionsList[i].FeildValidation!=null&&
        // את הבדיקה הבאה יש להוריד
        //CriterionsList[i].TypeEnum!=TypesEnum.PartOfaList&&
        !PartOfaList&&
        CriterionsList[i].FeildValidation.indexOf('required')>-1)
      {
        this.FormValidations.push(CriterionsList[i]);
        CriterionsList[i].required=true;
      }
      if(CriterionsList[i].TypeEnum==TypesEnum.PartOfaList)
       this.saveRequiredValidations(CriterionsList[i].CriterionsofAreasTree,true);
      else
       this.saveRequiredValidations(CriterionsList[i].CriterionsofAreasTree,PartOfaList);
       for(let j=0;j< CriterionsList[i].CriterionsofAreasTree.length;j++)
       {
        if(CriterionsList[i].CriterionsofAreasTree[j].required)
        {
          CriterionsList[i].required=true;
          break;
        } 
       }
    }
  }
  ChooseTitle(event:SimpleObject)
  {
    if(this.FormValidations.length>0)
      alert('טופס שגוי');
    // if(this.CriterionsForm.invalid)
    //    alert(this.CriterionsForm.errors);
    else
    {
      //console.log(event.tab);
      this.Title=event;
      this.CriterionsofAreaListSmall=this.RequestServ.Request.CriterionsofRequests.filter(x=>
        x.CriterionsTitleCode==event.Code); 
     if(this.CriterionsofAreaListSmall==null)
     this.CriterionsofAreaListSmall=new Array<CriterionsofAreas>(); 
     this.saveRequiredValidations(this.CriterionsofAreaListSmall);
    }
  }
  changeIndex()
  {
    this.activeIndex++;
  }
    TypesFunc(List=this.RequestServ.Request.CriterionsofRequests)
    {
      for(let i=0;i<List.length;i++)
      {
   // הערה: אם בכל מקרה עושים המרה לאי נום בשרת, עדיף כבר להחזיר רק את ערכי האינום בלי טיפוס מספרי 
   // אולי לחשוב על שימוש במספרים באינום- ואלו יהיו המספרים במסד
   switch(List[i].CriterionsType)
   {
    case 1: List[i].TypeEnum=this.EnumTypes.PeopleArea;;break;
    case 2: List[i].TypeEnum=this.EnumTypes.List;break;
    case 3: List[i].TypeEnum=this.EnumTypes.Number;break;
    case 4: List[i].TypeEnum=this.EnumTypes.Boolean;break;
    case 5: List[i].TypeEnum=this.EnumTypes.Date;break;
    case 6: List[i].TypeEnum=this.EnumTypes.Hour;break;
    case 7: List[i].TypeEnum=this.EnumTypes.PartOfaList;break;
    case 8: List[i].TypeEnum=this.EnumTypes.Place;break;
   }
   if(List[i].CriterionsofAreasTree.length>0) 
   this.TypesFunc(List[i].CriterionsofAreasTree) 
      }
    }
    
    // ChoosePeople(Code:number)
    // {
    //   this.showprophilbutton=true;
    //   this.ChosenFavoritePeople.Code=Code;
    // }
    ShowSpecificProphil()
    {   
      this.showspecificpeopleprophil=true;
    }
    SubmitChosenPeople()
    {
    }
    ShowLivingPlace()
    {
     this.DisplayLivingPlace=!this.DisplayLivingPlace
    }
    ShowWorkingPlace()
    {
      this.DisplayWorkingPlace=!this.DisplayWorkingPlace
    }
    
    ShowLearningPlaces()
    {
      this.DisplayLearningPlaces=!this.DisplayLearningPlaces
    }
    ShowExperiencese()
    {
      this.DisplayExperiencese=!this.DisplayExperiencese
    }
    ShowFavoritePeople()
    {
      this.DisplayFavoritePeople=!this.DisplayFavoritePeople
    }
    ShowTimes()
    {
      this.DisplayTimes=!this.DisplayTimes
    }
  ChooseType(Type:number)
  {
   this.TypeofNewCriterion=Type
  }
  OpenList()
  {
   this.ShowTypes=!this.ShowTypes;
  }
  @ViewChildren('myform') components:QueryList<any>;
 RemoveHiddenTitles(event:any,AddOrRemove:boolean)
  {for(let i=0;i<this.components.length;i++)
    {
      if(event.innerText!=this.components.toArray()[i].nativeElement.innerText)
      {
        if(AddOrRemove)
        {
          this.components.toArray()[i].nativeElement.hidden=true;
        }
        else
        {
          this.components.toArray()[i].nativeElement.hidden=false;
        }
      }       
    }     
  }
  FormFunc(event)
  {
    for(let i=0;i<this.components.toArray().length;i++)
      if(event.srcElement.innerText!=this.components.toArray()[i].nativeElement.innerText)
      {      
       if(event.srcElement.getAttribute('class').search('active')==-1)
       {
        event.srcElement.active=false;
        this.RemoveHiddenTitles(event.srcElement,true)
        console.log('khhjjh')
       }
         else
         {
          event.srcElement.active=true;
          this.RemoveHiddenTitles(event.srcElement,false)
         }
      }
  }
  OkFunc()
  {
    this.modelV=true;
    if(this.rightChoice==0)
    {
      this.RequestServ.Request.SendingJobOffersOnceaDay=false;
      this.RequestServ.Request.SendingJobOffersWheneverThereIsaSuitableOffer=true
    }
    else if(this.rightChoice==1)
    {
      this.RequestServ.Request.SendingJobOffersWheneverThereIsaSuitableOffer=false;
      this.RequestServ.Request.SendingJobOffersOnceaDay=true
    }
    this.RequestServ.sendRequest().subscribe(
      data=>{
        console.log('data',data);
        this.RequestServ.JobOffers=data;
        this.myrouter.navigate(['joboffers']);
        //מחני גרוזובסקי - לא עובד
        // let url = this.myrouter.createUrlTree(['/joboffers']);
        //  window.open(url.toString(), '_blank');
        // window.open("http://localhost:4200/joboffers", "_blank"); // Open new tab
      },
      error=>console.log(error.message),
      ()=>console.log('finished')
    );
  }
  model()
  {
    this.SendingJobOffers=true;
  }
  showConfirm(ele) {
  if(this.FormValidations.length>0)
      alert('טופס שגוי');
  //  if(this.CriterionsForm.invalid)
  //     alert(this.CriterionsForm.errors);
  else
  {
    //לבדוק אם זה תקין
    if(this.activeIndex!=this.TitlesList[this.TitlesList.length-1].Code-1)
    {
      this.changeIndex();
      this.ChooseTitle(this.TitlesList[this.activeIndex]);
    }
    else
    {
      this.messageService.clear();
      this.messageService.add({key: 'c', sticky: true, severity:'warn', summary:'Are you sure?', detail:'Confirm to proceed'});
  
    }
  }
}
InValid(i:CriterionsofAreas)
{
  if(!this.FormValidations.find(x=>x==i))
   this.FormValidations.push(i);
}
Valid(i:CriterionsofAreas)
{
 if(this.FormValidations.find(x=>x==i))
  this.FormValidations=this.FormValidations.filter(x=>x!=i);
  if(i.TypeEnum==TypesEnum.List)
  { 
   for(let j=0;j<i.CriterionsofAreasTree.length;j++)
   {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
     if(i.ValueofCriterion!=null&&i.ValueofCriterion.length)
      if(i.ValueofCriterion.find(x=>x==i.CriterionsofAreasTree[j].CriterionofAreaCode))
       {
        this.saveRequiredValidations(i.CriterionsofAreasTree[j].CriterionsofAreasTree);
        for(let t=0;t<i.CriterionsofAreasTree[j].CriterionsofAreasTree.length;t++)
        {
          if(i.CriterionsofAreasTree[j].CriterionsofAreasTree[t].required)
          {
            i.CriterionsofAreasTree[j].required=true;
            break;
          }
        }
       }
   } 
  }
}
onConfirm() {
  this.messageService.clear('c');
}

onReject() {
  this.messageService.clear('c');
}

clear() {
  this.messageService.clear();
}
  }
  
