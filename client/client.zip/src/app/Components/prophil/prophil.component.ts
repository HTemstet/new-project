import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { PeopleAreaService } from 'src/app/Services/people-area.service';
import { PeopleService } from 'src/app/Services/people.service';
import { AreaService } from 'src/app/Services/area.service';
import { PeopleAreaandArea } from 'src/app/Classes/PeopleAreaandArea';
import { MessageService } from 'primeng/components/common/messageservice';
import { Area } from 'src/app/Classes/Area';


@Component({
  selector: 'app-prophil',
  templateUrl: './prophil.component.html',
  styleUrls: ['./prophil.component.css']
})
export class ProphilComponent implements OnInit {
  @Input() specificpeople=this.PeopleServ.surf.Code;
  show=false;
 ind='';
 ShowLogo=false
 ShowCV=false
 ShowAdses=false
 ShowRecommends=false
 Logo='';
 CV='';
 Adses=new Array<string>();
 Recommends=new Array<string>();
 pa=new PeopleAreaandArea();
 RecuitingEmployees=false;
 RecuitingEmployers=false;
 AddRec=false;
 newRecommend='';
 ShowEmloyeeDetails=false;
 DisplayAllAreas=false;  SelectedRadio=null;
 ExistsRadio=false;
  ngOnInit() {
    this.PeopleAreaServ.PeopleAreaToAdd=-1;
    this.SelectedRadio=-1;
    if(this.specificpeople==null)
    {
      this.PeopleAreaServ.getAreas().
      subscribe(
        data=>this.PeopleAreaServ.areasOfPeople=data,
        error=>console.log(error.message),
        ()=>console.log('finished')
      );;
      this.show=false;
    }
    else
      if(this.specificpeople!=this.PeopleServ.surf.Code)
      {
      this.PeopleAreaServ.areasOfPeople=null;
      this.show=true;
      }
      else
      {
        this.PeopleAreaServ.getEmployeeAreas().subscribe(
          data=>
        {
            this.PeopleAreaServ.areasOfPeople=data
        }
          ,
          error=>console.log(error.message),
          ()=>console.log('finished')
        );
        this.PeopleAreaServ.getEmployerAreas().subscribe(
          data=>
        {
            this.PeopleAreaServ.Employerareas=data
        }
          ,
          error=>console.log(error.message),
          ()=>console.log('finished')
        );
      }       
  };
  constructor(private AreaServ:AreaService,private PeopleServ:PeopleService,
    private PeopleAreaServ:PeopleAreaService,private messageService: MessageService) { }
  newAreaBlur()
  {
    if(this.PeopleAreaServ.PeopleAreaToAdd==-1||this.PeopleAreaServ.PeopleAreaToAdd==0)
      this.PeopleAreaServ.PeopleAreaToAdd=0;  
  }
  newRadioBlur()
  {
    if(this.SelectedRadio==-1||this.SelectedRadio==null)
    this.SelectedRadio=null;
  }
  RadioChanged()
  {
    this.ExistsRadio=false;
    if(this.PeopleAreaServ.PeopleAreaToAdd!=null&&
      this.PeopleAreaServ.PeopleAreaToAdd!=0&&this.SelectedRadio!=-1)
    {
      let a=this.PeopleAreaServ.areasOfPeople.filter(x=>
        x.AreaCode==this.PeopleAreaServ.PeopleAreaToAdd);
        alert(this.SelectedRadio)
        if(a)
        {
          switch (this.SelectedRadio) {
            case '0': if(a.filter(x=>!x.RecruitingEmployees&&!x.RecruitingEmployers)
            .length>0)
            this.ExistsRadio=true;
                break;
            case '1':  if(a.filter(x=>x.RecruitingEmployees)
            .length>0)this.ExistsRadio=true;
                break;
            case '2':  if(a.filter(x=>x.RecruitingEmployers)
            .length>0)this.ExistsRadio=true;
                break;
        }  
      } 
    }
  }
 ShowAreaEmployeeDetails()
  {
    if(this.show==false)
    {
      this.ShowEmloyeeDetails=!this.ShowEmloyeeDetails;
      this.DisplayAllAreas=false;
    }
    else
     this.show=!this.show;
  }
  ConfirmDeleteEmployeeArea()
  {
    this.showConfirm();
  }
  NotExistsAreas=new Array<Area>();
  ShowAllAreas()
  {
    this.AreaServ.getAreas();
    this.DisplayAllAreas=!this.DisplayAllAreas;
    this.ShowEmloyeeDetails=false;
    this.NotExistsAreas=this.AreaServ.Allareas.filter(x=>
      this.PeopleAreaServ.areasOfPeople.filter(y=>y.AreaCode==x.Code).length<3);
  }
  SelectedAreaToAdd(i:number)
  {
   this.PeopleAreaServ.PeopleAreaToAdd=i;
   this.RadioChanged();
  }
  RemovePeopleArea()
  {//להוסיף הודעת אישור או ביטול ורק אם אושר להמשיך את ביצוע הפונקציה
    this.PeopleAreaServ.DeletePeopleArea().subscribe(
      data=>{alert('התחום נמחק בהצלחה');
      this.PeopleAreaServ.getEmployeeAreas().
      subscribe(
        data=>this.PeopleAreaServ.areasOfPeople=data,
        error=>console.log(error.message),
        ()=>console.log('finished')
      );
      this.PeopleAreaServ.getEmployerAreas().
      subscribe(
        data=>this.PeopleAreaServ.Employerareas=data,
        error=>console.log(error.message),
        ()=>console.log('finished')
      );
    },
      error=>console.log(console.log(error.message)),
     ()=>console.log('finished')
  );
  }
  CloseEmployeeDetails()
  {
    this.ShowEmloyeeDetails=false;
  }
 ShowPeopleAreaDetails(Code:number)
 {
   this.ShowLogo=this.ShowCV =this.ShowAdses=this.ShowRecommends=false;
   this.PeopleAreaServ.PeopleArea=Code;
   this.show=true;
 }
 GetLogo()
 {
  this.PeopleAreaServ.getLogo().subscribe(
  data=>{this.Logo=data;
  this.ShowLogo=!this.ShowLogo},
  error=>console.log(console.log(error.message)),
 ()=>console.log('finished')
 );
 }
 GetCV()
 {
    this.PeopleAreaServ.getCV().subscribe(
    data=>{this.CV=data;
    this.ShowCV=!this.ShowCV},
    error=>console.log(console.log(error.message)),
   ()=>console.log('finished')
   );
 }
 GetAdses()
 {
    this.PeopleAreaServ.getadsByAreaAndPeople().subscribe(
    data=>{
    this.PeopleAreaServ.adses=data;
    this.Adses=data;
    this.ShowAdses=!this.ShowAdses},
    error=>console.log(console.log(error.message)),
   ()=>console.log('finished')
   );
 }
 GetRecommends()
 {
    this.PeopleAreaServ.getRecommends().subscribe(
    data=>{this.Recommends=data;
    this.ShowRecommends=!this.ShowRecommends},
    error=>console.log(console.log(error.message)),
   ()=>console.log('finished')
   );
 }
 GetProphilBySwitch(Text:string)
 {
switch(Text)
{
  case 'Logo':this.GetLogo();break;
  case 'CV':this.GetCV();break;
  case 'Adses':this.GetAdses();break;
  case 'Recommends':this.GetRecommends();break;
}
 }
 RemoveFile(FolderName:string,index=0)
 {
this.PeopleAreaServ.RemoveFile(FolderName,index).subscribe(
  data=>{alert('הקובץ נמחק בהצלחה');this.GetProphilBySwitch(FolderName)},
  error=>console.log(console.log(error.message)),
 ()=>console.log('finished')
 );
 }
 AddRecommend()
 {
this.AddRec=true;
 }
 SaveRecommend()
 {
   this.PeopleAreaServ.AddRecommend(this.newRecommend).subscribe(
    data=>{alert('ההמלצה נשמרה');this.AddRec=false;
  this.GetRecommends()},
    error=>console.log(console.log(error.message)),
   ()=>console.log('finished')
   );
 }
 UpdateRecommend(ind:number,Rec:string)
 {
this.PeopleAreaServ.UpdateRecommend(ind,Rec).subscribe(
  data=>{alert('השינויים נשמרו בהצלחה');this.GetRecommends()},
  error=>console.log(console.log(error.message)),
 ()=>console.log('finished')
 );
 }
 CloseAreas()
 {
  this.ShowEmloyeeDetails=false;
 }
 AddPeopleArea()
 {
   if(this.SelectedRadio==1)
   {
    this.RecuitingEmployees=true;
   }
   else 
     if(this.SelectedRadio==2)
     {
       this.RecuitingEmployers=true;
     }
     if(!this.ExistsRadio&&this.PeopleAreaServ.PeopleAreaToAdd!=0&&
      this.PeopleAreaServ.PeopleAreaToAdd!=-1&&
      this.SelectedRadio!=null&&this.SelectedRadio!=-1)
    this.PeopleAreaServ.AddepeopleArea(this.RecuitingEmployees,this.RecuitingEmployers).subscribe(
      data=>{ this.CloseAreas();
      alert('התחום נוסף בהצלחה');
      this.ShowLogo=this.ShowCV =this.ShowAdses=this.ShowRecommends=false;
      alert(data)
      this.PeopleAreaServ.PeopleArea=data;
      this.show=true;
      this.SelectedRadio=null;
      this.DisplayAllAreas=false;
      this.ShowEmloyeeDetails=true;
      this.PeopleAreaServ.PeopleAreaToAdd=0;
      this.PeopleAreaServ.getEmployeeAreas().
      subscribe(
        data=>this.PeopleAreaServ.areasOfPeople=data,
        error=>console.log(error.message),
        ()=>console.log('finished')
      );
      this.PeopleAreaServ.getEmployerAreas().
      subscribe(
        data=>this.PeopleAreaServ.Employerareas=data,
        error=>console.log(error.message),
        ()=>console.log('finished')
      );
      this.RecuitingEmployees=this.RecuitingEmployers=false;
      },
      error=>console.log(console.log(error.message)),
     ()=>console.log('finished')
     );
     else
      {
        this.newAreaBlur();
        this.newRadioBlur();
      }
 }
 FileList:FileList;
  fileName='';
  fileChange(event)
  {
    this.FileList=event.target.files;
  }
  CancelationChangeFile()
  {
    this.FileList=null;
  }
  SentToPlacing(FolderName:string)
  {
    if(this.FileList!=null&&this.FileList.length>0)
    {
      let File:File=this.FileList[0];
      this.fileName=File.name;
      this.PeopleAreaServ.Placing(File,FolderName).subscribe(
        data=>{
          alert(FolderName)
          this.GetProphilBySwitch(FolderName)
        },
        error=>console.log(console.log(error.message)),
       ()=>console.log('finished')
    );
    }
  }
  showConfirm() {
    this.messageService.clear();
    this.messageService.add({key: 'c', sticky: true, severity:'warn', summary:'Are you sure?', detail:'Confirm to proceed'});
}
onConfirm() {
  this.messageService.clear('c');
  this.RemovePeopleArea();
}

onReject() {
  this.messageService.clear('c');
}

clear() {
  this.messageService.clear();
}
}
