import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProphilComponent } from './prophil.component';

describe('ProphilComponent', () => {
  let component: ProphilComponent;
  let fixture: ComponentFixture<ProphilComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProphilComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProphilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
