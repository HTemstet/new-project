import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AreaMenuComponent } from './area-menu.component';

describe('AreaMenuComponent', () => {
  let component: AreaMenuComponent;
  let fixture: ComponentFixture<AreaMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AreaMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AreaMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
