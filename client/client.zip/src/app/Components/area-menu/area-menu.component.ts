import { Component, OnInit, Input } from '@angular/core';
import { AreaService } from 'src/app/Services/area.service';
import { Router } from '@angular/router';
import { PeopleAreaService } from 'src/app/Services/people-area.service';

@Component({
  selector: 'app-area-menu',
  templateUrl: './area-menu.component.html',
  styleUrls: ['./area-menu.component.css']
})
export class AreaMenuComponent implements OnInit {

  constructor(private AreaServ:AreaService,
    private PeopleAreaServ:PeopleAreaService,
    private myrouter:Router) { }

  ngOnInit() {
  }
  gotoHomeSpecific()
{
  this.PeopleAreaServ.getRandomofadsByArea().subscribe(
    data=>{
      console.log(data)
      this.PeopleAreaServ.adses=data;
      console.log(this.PeopleAreaServ.adses)
      this.AreaServ.aboutArea=this.AreaServ.FullArea.AboutArea;
      this.AreaServ.aboutArea=this.AreaServ.FullArea.AboutArea;
      this.myrouter.navigateByUrl('/enter', {skipLocationChange: true}).then(()=>
      this.myrouter.navigate(["ads"]));
    },
    error=>console.log(error.message),
    ()=>console.log('finished')
  );
}
}
