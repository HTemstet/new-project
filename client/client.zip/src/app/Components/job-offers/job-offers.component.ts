import { Component, OnInit } from '@angular/core';
import { RequestService } from 'src/app/Services/request.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-job-offers',
  templateUrl: './job-offers.component.html',
  styleUrls: ['./job-offers.component.css']
})
export class JobOffersComponent implements OnInit {
  constructor(private RequestServ:RequestService,private myrouter:Router) { }

  ngOnInit() {
  }
  ChooseOffer(Code:number)
 {
  this.RequestServ.Request.CriterionsofRequests=this.RequestServ.JobOffers[Code].CriterionsofRequests;
  this.myrouter.navigateByUrl('ads', {skipLocationChange: true}).then(()=>
  this.myrouter.navigate(["/request"]));
 }

//  
step = 0;

setStep(index: number) {
  this.step = index;
}

nextStep() {
  this.step++;
}

prevStep() {
  this.step--;
}
}
