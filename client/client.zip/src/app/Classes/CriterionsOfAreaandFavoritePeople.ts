import { CriterionsofAreas } from './CriterionsofAreas';
import { PeopleAreaandArea } from './PeopleAreaandArea';

export class CriterionsOfAreaandFavoritePeople
    {
        constructor(
        public CriterionsofAreaList=new Array<CriterionsofAreas>(),
        public FavoritePeopleList=new Array<PeopleAreaandArea>()
        ){}
 }