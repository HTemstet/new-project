export class Area
{
    constructor(
        public Code=0,
        public Name='',
        public AboutArea=''
    ){}
}