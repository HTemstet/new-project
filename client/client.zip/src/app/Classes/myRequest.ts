import { CriterionsofAreas } from './CriterionsofAreas';

export class myRequest
{
    constructor(
        public PeopleCode=0,
        public AreaCode=0,
        public Employee=false,
        public SendingJobOffersOnceaDay=false,
        public SendingJobOffersWheneverThereIsaSuitableOffer=false,
        public CriterionsofRequests=new Array<CriterionsofAreas>(),
        //אולי צריך למחוק
        public AdjustmentPercentages=0
    ){}
}