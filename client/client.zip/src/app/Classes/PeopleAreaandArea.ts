export class PeopleAreaandArea
{
    constructor(
        public Code=0,
        public PeopleCode=0,
        public AreaCode=0,
        public Name='',
        public RecruitingEmployees=false,
        public RecruitingEmployers=false
    ){}
}