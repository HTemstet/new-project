import { People } from './People';
import { CriterionsofAreas } from './CriterionsofAreas';

export class JobOffers
{
    constructor(
        public RequestCode=0,
        public PeopleOffer:People,
        public CriterionsofRequests:Array<CriterionsofAreas>=[],
        public AdjustmentPercentages=0
    ){}
}