export class SimpleObject
{
    constructor(
        public Code=0,
        public Name=''
    ){}
}