export class People
{
constructor(public Code=1,
    public PeoplePassword='00000000', 
    public TempPassword='00000000',
    public FirstName='',
    public Name='',
    public Phone='',
    public Email='',
 ){}
}