export class ValuesofCriterions
{
    constructor(
      public  CriterionofAreaCode=0,
      public  ValueofCriterionValue='',
      public  LevelofImportance=0,
      public  ComparisonOperator=1 
    ){}
}