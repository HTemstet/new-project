import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { EnterComponent } from './Components/enter/enter.component';
import { HomeComponent } from './Components/home/home.component';
import { AdsComponent } from './Components/ads/ads.component';
import { PersonalDetailsComponent } from './Components/personal-details/personal-details.component';
import { RequestComponent } from './Components/request/request.component';
import { ProphilComponent } from './Components/prophil/prophil.component';
import { JobOffersComponent } from './Components/job-offers/job-offers.component';
import { DisplaySelectComponent } from './Components/display-select/display-select.component';
import { ValidationComponent } from './Components/validation/validation.component';
import { AboutComponent } from './Components/about/about.component';
import { routing } from 'src/app/OtherPages/RoutingFile';
import { AgmCoreModule } from '@agm/core';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { Ng5SliderModule } from 'ng5-slider';
import {MatSliderModule} from '@angular/material/slider';
import { ToastModule } from 'primeng/toast';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonModule } from 'primeng/button';
//גלריית תמונות
import { GalleriaModule } from 'primeng/galleria';
//כפתור כניסה
import { MatInputModule } from '@angular/material/input';
import { InputTextModule } from 'primeng/inputtext';
import { MessageService } from 'primeng/components/common/messageservice';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTreeModule } from '@angular/material/tree';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatRadioModule } from '@angular/material/radio';
import {RadioButtonModule} from 'primeng/radiobutton';
import { CriterionsTreeComponent } from './Components/criterions-tree/criterions-tree.component';
import { DialogModule} from 'primeng/dialog';
import { AreaMenuComponent } from './Components/area-menu/area-menu.component';
import { DisplayButtonComponent } from './Components/display-button/display-button.component';
import { LoadingComponent } from './Components/loading/loading.component';
import { StepsModule } from 'primeng/steps';
import { AboutEmployerComponent } from './Components/about-employer/about-employer.component';
import { FreeorbyrAreaSerachComponent } from './Components/freeorbyr-area-serach/freeorbyr-area-serach.component';
//לקומפ' request
import {MatTabsModule} from '@angular/material/tabs';
// job-offers
import {MatExpansionModule} from '@angular/material/expansion';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

@NgModule({
  declarations: [
    EnterComponent,
    HomeComponent,
    AdsComponent,
    PersonalDetailsComponent,
    RequestComponent,
    ProphilComponent,
    JobOffersComponent,
    DisplaySelectComponent,
    ValidationComponent,
    AboutComponent,
    CriterionsTreeComponent,
    AreaMenuComponent,
    DisplayButtonComponent,
    LoadingComponent,
    AboutEmployerComponent,
    FreeorbyrAreaSerachComponent
  ],
  imports: [HttpClientModule,FormsModule,GooglePlaceModule,Ng5SliderModule,MatSliderModule,
    ToastModule,ButtonModule,GalleriaModule,DialogModule,RadioButtonModule,
    MatCheckboxModule,MatTreeModule,MatButtonModule,MatIconModule,MatSelectModule,MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,MatInputModule,MatTabsModule,MatExpansionModule,
    BrowserAnimationsModule,InputTextModule,StepsModule,
    BrowserModule,RouterModule.forRoot(routing),
    AgmCoreModule.forRoot({
      apiKey:'AIzaSyAj13gY0dRy3LKgxfbOkCPaqq_twe8eR3k',
       libraries: ['places','geometry']}),
  //   RouterModule.forRoot(
  //   routing,
  //   {enableTracing: true } 
  // )
  ],
  providers: [MessageService],
  bootstrap: [HomeComponent]
})
export class AppModule { }
