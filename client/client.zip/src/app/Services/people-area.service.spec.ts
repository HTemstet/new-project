import { TestBed } from '@angular/core/testing';

import { PeopleAreaService } from './people-area.service';

describe('PeopleAreaService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PeopleAreaService = TestBed.get(PeopleAreaService);
    expect(service).toBeTruthy();
  });
});
