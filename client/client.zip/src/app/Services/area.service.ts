import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PeopleService } from './people.service';
import { Area } from '../Classes/Area';

@Injectable({
  providedIn: 'root'
})
export class AreaService{
  basicUrl='http://localhost:53939/api/Area/';
  Allareas:Array<Area>=null;
  Area:number=null;
  FullArea:Area;
  aboutArea='';
  AreaSearch=null;
  showAreas=null;
  constructor(private myhttp:HttpClient,private PeopleServ:PeopleService) {}
  getAreas():void
  {
    if(this.Allareas==null)
      this.myhttp.get<Array<Area>>(this.basicUrl+'getAllAreas').subscribe(
      data=>this.Allareas=data,
      error=>console.log(error.message),
      ()=>console.log('finished')
    );
  }
}
