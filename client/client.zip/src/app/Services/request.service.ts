import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { myRequest } from '../Classes/myRequest';
import { PeopleService } from './people.service';
import { CriterionsofAreas } from '../Classes/CriterionsofAreas';
import { AreaService } from './area.service';

import { People } from '../Classes/People';
import { CriterionsOfAreaandFavoritePeople } from '../Classes/CriterionsOfAreaandFavoritePeople';
import { PeopleAreaandArea } from '../Classes/PeopleAreaandArea';
import { SimpleObject } from '../Classes/SimpleObject';
import { JobOffers } from '../Classes/JobOffers';
import { debug } from 'util';
export  enum TypesEnum {PeopleArea,List,Number,Boolean,Date,Hour,PartOfaList,Place}
@Injectable({
  providedIn: 'root'
})
export class RequestService {
  constructor(private myhttp:HttpClient, private PeopleServ:PeopleService,private AreaServ:AreaService) { }
  basicUrl='http://localhost:53939/api/Request/';
  Request=new myRequest();
  FavoritePeople:Array<PeopleAreaandArea>;
  JobOffers:Array<JobOffers>;
  getTitles():Observable<Array<SimpleObject>>
  {
    return this.myhttp.get<Array<SimpleObject>>(this.basicUrl+'getAllCriterionsTitles'); 
  }
  getAllCriterionsByArea():Observable<CriterionsOfAreaandFavoritePeople>
  {
    return this.myhttp.get<CriterionsOfAreaandFavoritePeople>(this.basicUrl+'getCriterions/'+this.AreaServ.Area+"/"+this.Request.Employee);
  }
  GetFavoritePeople():Observable<Array<People>>
  {
    return this.myhttp.get<Array<People>>(this.basicUrl+'GetFavoritePeople/'+this.AreaServ.Area+'/'+this.PeopleServ.surf.Code);
  }
  sendRequest():Observable<Array<JobOffers>>
  {
    this.Request.PeopleCode=this.PeopleServ.surf.Code;
    this.Request.AreaCode=this.AreaServ.Area,this.Request;
    debugger;
    return this.myhttp.post<Array<JobOffers>>(this.basicUrl+'SavemyRequest',this.Request); 
  }

}
