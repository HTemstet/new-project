import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { People } from '../Classes/People';

@Injectable({
  providedIn: 'root'
})
export class PeopleService {
  constructor(private myhttp:HttpClient) { 
  }
  surf:People=new People();
  basicUrl='http://localhost:53939/api/People/';
  checkpeoplePassword(Email:string,Pass:string):Observable<People>
  {
    return this.myhttp.post<People>(this.basicUrl+'ExistsPeoplePassword',{Email:Email,PeoplePassword:Pass});
  }
  checkpeopleTempPassword(Email:string,Pass:string):Observable<boolean>
  {
    return this.myhttp.post<boolean>(this.basicUrl+'ExistsPeopleTempPassword',{Email:Email,PeoplePassword:Pass});
  }
  changePassword(Email:string,TempPass:number,Pass:string):Observable<People>
  {
    return this.myhttp.post<People>(this.basicUrl+'ChangePassword',{Email:Email,TempPassword:TempPass,PeoplePassword:Pass});
  }
  updatepeople():Observable<any>
  {
   return this.myhttp.put<any>(this.basicUrl+'PutPeopleDetails',this.surf);
  }
}
