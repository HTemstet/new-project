import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PeopleService } from './people.service';
import { AreaService } from './area.service';
import { PeopleAreaandArea } from '../Classes/PeopleAreaandArea';
import { SimpleObject } from '../Classes/SimpleObject';

@Injectable({
  providedIn: 'root'
})
export class PeopleAreaService {
  constructor(private myhttp:HttpClient,private AreaServ:AreaService,private PeopleServ:PeopleService) { }
  basicUrl='http://localhost:53939/api/PeopleArea/';
  AreaDetailsCode=0
  PictureNative="http://localhost:53939/Files/"
  Allads:Array<string>;
  adses:Array<string>;
  //אולי לשנות את הליסט הבא לשם המתאים לרשימת תחומי עובד
  areasOfPeople:Array<PeopleAreaandArea>=null;
  Employerareas:Array<PeopleAreaandArea>=null;
  PeopleArea=0;
  PeopleAreaToAdd=0;
  getAllads():Observable<string[]>
  {
    return this.myhttp.get<string[]>(this.basicUrl+'GetAllAds');
  }
  getRandomofadsByArea():Observable<string[]>
  {
    return this.myhttp.get<string[]>(this.basicUrl+'GetAdsesByArea/'+this.AreaServ.Area);
  }
  getEmployeeAreas():Observable<Array<PeopleAreaandArea>>
  {
     return this.myhttp.get<Array<PeopleAreaandArea>>(this.basicUrl+'getPeopleEmployeeAreas/'+ this.PeopleServ.surf.Code);
  }
  getEmployerAreas():Observable<Array<PeopleAreaandArea>>
  {
     return this.myhttp.get<Array<PeopleAreaandArea>>(this.basicUrl+'getPeopleEmployerAreas/'+ this.PeopleServ.surf.Code);
  }
  getAreas():Observable<Array<PeopleAreaandArea>>
  {
    return this.myhttp.get<Array<PeopleAreaandArea>>(this.basicUrl+'getAllAreas');
  }
  getLogo():Observable<string>
  {
    return this.myhttp.get<string>(this.basicUrl+'GetLogoByPeopleArea/'+this.PeopleArea)
  }
  getCV():Observable<string>
  {
    return this.myhttp.get<string>(this.basicUrl+'GetCVByPeopleArea/'+this.PeopleArea)
  }
  getRecommends():Observable<Array<string>>
  {
    return this.myhttp.get<Array<string>>(this.basicUrl+'GetRecommendsByPeopleArea/'+this.PeopleArea)
  }
  getadsByAreaAndPeople():Observable<string[]>
  {
    return this.myhttp.get<string[]>(this.basicUrl+'GetPeopleAreaAdses/'+this.PeopleArea);
  }
  AddepeopleArea(RecuitingEmployees:boolean,RecuitingEmployers:boolean):Observable<number>
  {
    return this.myhttp.post<number>(this.basicUrl+'AddPeopleArea',new PeopleAreaandArea(0,this.PeopleServ.surf.Code,this.PeopleAreaToAdd,'',RecuitingEmployees,RecuitingEmployers));
  }
  DeletePeopleArea()
  {
    return this.myhttp.delete<any>(this.basicUrl+'DeletePeopleArea/'+this.PeopleArea);
  }
  FileName='';
  Placing(file:File,FolderName:string):Observable<any>
 {
this.FileName=file.name.split('.')[0]
let formData=new FormData();
formData.append('uploadFile',file,file.name);
return this.myhttp.post<any>(this.basicUrl+'PostFile/'+this.PeopleArea+'/'+this.PeopleServ.surf.Code+'/'+this.areasOfPeople.find(x=>x.Code==this.PeopleArea).AreaCode+"/"+FolderName,formData);
 }
 RemoveFile(FolderName:string,delind: number)
{
  return this.myhttp.delete<any>(this.basicUrl+'RemoveFile/'+this.PeopleArea+"/"+FolderName+"/"+delind);
}
 AddRecommend(newRec:string)
 {
  return this.myhttp.post<any>(this.basicUrl+'AddRecommend/'+this.PeopleArea+"/"+newRec, null);
 }
 UpdateRecommend(ind:number , Rec: string) 
 {
  return this.myhttp.put<any>(this.basicUrl+'PutRecommend/'+this.PeopleArea+"/"+ind+"/"+Rec,null);
 }
}
